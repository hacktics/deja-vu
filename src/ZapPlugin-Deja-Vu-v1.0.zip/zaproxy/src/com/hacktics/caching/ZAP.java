package com.hacktics.caching;

import java.io.IOException;
import java.net.URI;
import java.util.*;

import org.apache.commons.httpclient.URIException;
import org.parosproxy.paros.control.Control;
import org.parosproxy.paros.db.TableHistory;
import org.parosproxy.paros.extension.history.ExtensionHistory;
import org.parosproxy.paros.extension.manualrequest.ManualRequestEditorDialog;
import org.parosproxy.paros.model.Model;
import org.parosproxy.paros.model.Session;
import org.parosproxy.paros.model.SiteNode;
import org.parosproxy.paros.network.HttpMessage;
import org.parosproxy.paros.network.HttpSender;

import com.hacktics.caching.parsers.Utils;
import com.sun.corba.se.impl.javax.rmi.CORBA.Util;


public class ZAP {
	
	private static long zapSessionID;
	
	public static final boolean ALLOW_STATE = true;
	public static final int INITIATOR = HttpSender.MANUAL_REQUEST_INITIATOR;
	private static HttpSender sender = new HttpSender(Model.getSingleton().getOptionsParam().getConnectionParam(), ALLOW_STATE,INITIATOR);
	
	public ZAP() {
		
	}

	/**
	 * 
	 * @return Returns all urls in the current zap session
	 */
	

	public static ArrayList<String> getURLsFromDomain() {
		ArrayList<String> result = new ArrayList<String>();
		Session session = Model.getSingleton().getSession();
		SiteNode root = (SiteNode) session.getSiteTree().getRoot();
		@SuppressWarnings("unchecked")
		Enumeration<SiteNode> en = root.children();
		while (en.hasMoreElements()) {
			SiteNode element = en.nextElement(); 
			String site = element.getNodeName();
			
			if (site.indexOf("//") >= 0) {
				site = site.substring(site.indexOf("//") + 2);
				
				if (site.contains(Utils.get_Site()))
				{
					Enumeration<SiteNode> childs = element.children();
					while (childs.hasMoreElements()) {
						SiteNode element2 = childs.nextElement(); 
						result.add(element2.getNodeName());
					
					}
					
					
				}

			}
			
		}

		return result;
			
	}
	public static ArrayList<String> getDomainsFromZap() {
		ArrayList<String> result = new ArrayList<String>();
		Session session = Model.getSingleton().getSession();
		SiteNode root = (SiteNode) session.getSiteTree().getRoot();
		@SuppressWarnings("unchecked")
		Enumeration<SiteNode> en = root.children();
		while (en.hasMoreElements()) {
			String site = en.nextElement().getNodeName();
			
			if (site.indexOf("//") >= 0) {
				site = site.substring(site.indexOf("//") + 2);
			}

			result.add(site);
			
		}

		return result;
	}
	
	public static int getProxyPort() {
		return Model.getSingleton().getOptionsParam().getProxyParam().getProxyPort();
	}
	
	public static String getProxyIP() {
		return Model.getSingleton().getOptionsParam().getProxyParam().getProxyIp();
	}
	
	public static HashMap<String, HttpMessage> getZAPResponsesForURL(String URL) {
		HashMap<String, HttpMessage> result = new HashMap<String, HttpMessage>();
		
		zapSessionID = Model.getSingleton().getSession().getSessionId();// Read only current session's history
		
		try {
			Vector<Integer> historyIDList;
			TableHistory tableHistory = Model.getSingleton().getDb()
					.getTableHistory();
			historyIDList = tableHistory.getHistoryList(zapSessionID);

			for (Integer historyID : historyIDList) {
				String historyURL = tableHistory.read(historyID).getHttpMessage().getRequestHeader().getURI().getURI();

				if (historyURL!="")
				{
					historyURL = historyURL.replace(" ","%20");
					URI url;
					try{
						url = new URI(historyURL);
					} catch (Exception ex)
					{
						url = null;
					}
					
					if (url!=null)
					{
						if (historyURL.contains(URL) && tableHistory.read(historyID).getHttpMessage().getResponseBody().length() > 0 ) {
							if (Utils.ExtensionExcluded(url.toString()) && url.getHost().contains(Utils.get_Site()))
							{
								result.put(historyURL, tableHistory.read(historyID).getHttpMessage());
							}
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	

	
	public static void showZapRepeater(HttpMessage hm) {
		ExtensionHistory extHist = (ExtensionHistory) Control.getSingleton().getExtensionLoader().getExtension("ExtensionHistory");
		if (extHist != null) {
			ManualRequestEditorDialog dialog = extHist.getResendDialog();
			dialog.setMessage(hm);
			dialog.setAlwaysOnTop(true);
			dialog.setVisible(true);
		}
	}
	
	public static void send(HttpMessage msg) {
		try {
			sender.sendAndReceive(msg);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
