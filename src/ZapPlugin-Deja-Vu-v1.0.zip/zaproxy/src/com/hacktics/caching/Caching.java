/**
 * 
 */
package com.hacktics.caching;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.parosproxy.paros.network.HttpMessage;

import com.hacktics.caching.gui.CachingView;
/**
 * @author alex.mor
 *
 */
public class Caching {

	public Caching(final HttpMessage hm) {	

		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				
				CachingView gui = new CachingView(hm);
				gui.createShowGUI();
				
			}
		});
	}

}
