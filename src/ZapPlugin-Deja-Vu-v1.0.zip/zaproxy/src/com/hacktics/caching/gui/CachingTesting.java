package com.hacktics.caching.gui;

import java.awt.BorderLayout;

import org.parosproxy.paros.extension.history.ExtensionHistory;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JList;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import javax.swing.JScrollPane;

import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.URIException;
import org.parosproxy.paros.model.HistoryReference;
import org.parosproxy.paros.model.Model;
import org.parosproxy.paros.model.Session;
import org.parosproxy.paros.model.SiteMap;
import org.parosproxy.paros.model.SiteNode;
import org.parosproxy.paros.network.HttpMalformedHeaderException;
import org.parosproxy.paros.network.HttpMessage;
import org.parosproxy.paros.network.HttpSender;

import com.hacktics.caching.ZAP;
import com.hacktics.caching.main.URLObject;
import com.hacktics.caching.parsers.Responses;
import com.hacktics.caching.parsers.Utils;
import com.hacktics.caching.parsers.wayback;
import com.sittinglittleduck.DirBuster.gui.JFrameHelp;

import difflib.DiffUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class CachingTesting extends JFrame implements  ActionListener {

	private JPanel contentPane;
	private JTextField txtChange;
	private static long zapSessionID;
	
	public static final boolean ALLOW_STATE = true;
	public static final int INITIATOR = HttpSender.MANUAL_REQUEST_INITIATOR;
	final JList lstLinks;
	private HashMap<String,String> newList;
	
	
	private DefaultListModel listModel;
	
	private HashMap<String,String> _links;
	private HashMap<String,String> _templinks = null;
	
	HashMap<String,HttpMessage> responses;
	private JTextField txtYear;
	
	
	public void setLinks(HashMap<String, String> links) {
		this._links = links;
	}
	
	public HashMap<String, String> getLinks() {
		return _links;
	}

	public CachingTesting() {

		
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		this.setResizable(false);
		this.setBounds(100, 100, 662, 183);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(400, 11, 243, 89);
		contentPane.add(panel);
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1);
		
		JLabel lblYear = new JLabel("Year");
		panel_1.add(lblYear);
		
		txtYear = new JTextField();
		panel_1.add(txtYear);
		txtYear.setColumns(10);
		
		JButton btnLiveChanged = new JButton("Check");
		panel_1.add(btnLiveChanged);
		
		btnLiveChanged.setActionCommand("Change");
		btnLiveChanged.addActionListener(this);
		
		JPanel panel_2 = new JPanel();
		panel.add(panel_2);
		
		JLabel lblChange = new JLabel("Similarity % = ");
		panel_2.add(lblChange);
		
		txtChange = new JTextField();
		panel_2.add(txtChange);
		txtChange.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 378, 131);
		contentPane.add(scrollPane);



		responses = ZAP.getZAPResponsesForURL(Utils.get_Site());
		
		lstLinks = new JList(getAllURLs());
		
		scrollPane.setViewportView(lstLinks);
		
		listModel = new DefaultListModel();

	}

	
	private String[] getAllURLs()
	{
		
		ArrayList<String> links = new ArrayList<String>();
		ArrayList<URLObject> urls = Utils.getURLs();
		
		for (URLObject url : urls)
		{
			if (url.get_URL()!=null) {
				links.add(url.get_URL()); 
			}
		}
		
		return links.toArray(new String[links.size()]);
	}
	
	
	private String getURLCachedResponse()
	{
		URLObject urlObj = Utils.getURLs().get(lstLinks.getSelectedIndex());
		HttpMessage http = urlObj.get_CacheObject().getArchiveSource(Utils.CachingSites.WayBackMachine).getArchiveParams().getMessage();
		String response = http.getResponseBody().toString();
		if (response!=null)
			return response;
		
		return null;
	
	}
	
	private String getURLResponse()
	{
		URLObject urlObj = Utils.getURLs().get(lstLinks.getSelectedIndex());
		String http = urlObj.get_Response();
		if (http!=null)
			return http;
		
		return null;
	
	}
	
	
	private HttpMessage getValueByIndex(HashMap<String,HttpMessage> map, int index)
	{
		List keys = new ArrayList(map.values());
		return (HttpMessage)keys.get(index);
	}
	
	private String[] getAllKeys(HashMap<String,HttpMessage> map){
		
		ArrayList<String> list = new ArrayList<String>();
	    for(String s : map.keySet()){
	    	list.add(s);
	    }
	    
	    return list.toArray(new String[list.size()]);
	}
	
	private Boolean CheckIfLinkAlive(String link)
	{
		URI site = null;
		try {
			site = new URI(link ,false);
		} catch (URIException | NullPointerException e) {
			e.printStackTrace();
		}
		HttpMessage _Request = null;
		try {
			_Request = new HttpMessage(site);
		} catch (HttpMalformedHeaderException e) {
			e.printStackTrace();
		}
		ZAP.send(_Request);
		
		if (_Request.getResponseHeader().getStatusCode() == 200)
		{
			return true;
		}
		
		return false;
	}
	
	private String getResponse(String link)
	{
		URI site = null;
		try {
			site = new URI(link ,false);
		} catch (URIException | NullPointerException e) {
			e.printStackTrace();
		}
		HttpMessage _Request = null;
		try {
			_Request = new HttpMessage(site);
		} catch (HttpMalformedHeaderException e) {
			e.printStackTrace();
		}
		ZAP.send(_Request);
		
		if (_Request.getResponseHeader().getStatusCode() == 200)
		{
			return _Request.getResponseBody().toString();
		}
		
		return "";
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		switch (e.getActionCommand()) {
		case "Live":
		{
			
/*			newList = new HashMap<String,String>();
			 for (int i = 0; i < lstLinks.getModel().getSize(); i++) {
				 	final int index = i;
		            final String item = (String)lstLinks.getModel().getElementAt(i);
		            
		            _templinks = this.getLinks();
		            Thread th = new Thread(new Runnable() {
		            	
		            	public void run()
		            	{
				            Boolean linkExist = CheckIfLinkAlive(item);
				            if (linkExist)
				            {
				    			listModel.addElement((String)item);
				    			lstLiveLinks.setModel(listModel);
				            	newList.put(item, getValueByIndex(_templinks,index));
				            	String s = newList.values().toString();
				            }
		            	}
		            });
		            th.start();

		        }*/
			 break;
		
		}
		case "Change":
		{
			final String item = lstLinks.getSelectedValue().toString();
			final String urlResponse = getURLResponse();
            Thread th = new Thread(new Runnable() {
            	final String year = txtYear.getText();
	            public void run()
	            {
	            	int prec = 0;
	            	String response = getURLCachedResponse();
	            	prec = Responses.GetResponsesSimilarity.getResponsesSimilarity(urlResponse,response);
	            	txtChange.setText(Integer.toString(prec));
	            }
            });
            
            th.start();
			 break;
		}
		
	}
		
	}
}
