package com.hacktics.caching.gui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.WindowEvent;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.hacktics.caching.CachingTestingLoader;
import com.hacktics.caching.ZAP;
import com.hacktics.caching.parsers.Utils;
import com.hacktics.caching.parsers.wayback;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.util.HashMap;

import java.net.InetSocketAddress;
import java.net.Proxy;

import org.apache.commons.httpclient.URIException;
import org.parosproxy.paros.network.HttpMessage;

public class CachingView extends JFrame implements ActionListener {
	
	
	//Info Components
	JFrame frame = new JFrame(APP_NAME);
	JPanel infoPanel = new JPanel();
	JPanel controlsPanel = new JPanel(new GridBagLayout());
	
	
	JTextField sYear;
	JTextField eYear;
	JTextField targetSite;
	JList<String> SupportedCachingSites;
	JButton btnGetYears = new JButton("Get Years");
	JButton About = new JButton("About");
	JLabel HelpLabel1 = new JLabel("The GetYears button");
	JLabel HelpLabel2 = new JLabel("allows you to check ");
	JLabel HelpLabel3 = new JLabel("snapshot years' ranges ");
	JLabel HelpLabel4 = new JLabel("for a target domain");

	// Request URL
	private String stringURL = "";
	private HttpMessage orgMessage;
	private String proxyHost = ZAP.getProxyIP();
	private int proxyPort = ZAP.getProxyPort();
	private Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));

	private String stringControlName = "";
	private String CacheSource = null;
	
	private static final String APP_NAME = "Deja-Vu - Conf";
	private static final String VERSION = "1.0";
	private static final String ABOUT = "Developer: Niv Sela\nResearchers: Niv Sela & Shay Chen\nCompany: HASC (Hacktics, Advanced Security Center)\nVersion:" + VERSION;	
	public CachingView(HttpMessage hm) {
		
		orgMessage = hm;
		if (hm!=null) {
			try {
				stringURL = hm.getRequestHeader().getURI().getURI();
			} catch (URIException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void createShowGUI() {
			
		Container contentPane = frame.getContentPane();
		initComponents(contentPane,frame);
		        
		frame.pack();
		frame.setSize(new Dimension(200, 300));
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		frame.setResizable(false);
		
        frame.addWindowListener( new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
				ArrayList<Utils.CachingSites> cacheSources = new ArrayList<Utils.CachingSites>();
				cacheSources.add(Utils.CachingSites.WayBackMachine);
				Utils.Configuration(Integer.parseInt(sYear.getText()), Integer.parseInt(eYear.getText()), targetSite.getText(), true, cacheSources ,true);
				Utils.ResetHistory();
                
            }
        } );
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		switch (e.getActionCommand()) {
			case "Save":
			{
				ArrayList<Utils.CachingSites> cacheSources = new ArrayList<Utils.CachingSites>();
				cacheSources.add(Utils.CachingSites.WayBackMachine);
				Utils.Configuration(Integer.parseInt(sYear.getText()), Integer.parseInt(eYear.getText()), targetSite.getText(), true, cacheSources ,true);
				Utils.ResetHistory();
				break;
			}
			
			case "GetYears":
			{
				ArrayList<Utils.CachingSites> cacheSources = new ArrayList<Utils.CachingSites>();
				cacheSources.add(Utils.CachingSites.WayBackMachine);
				Utils.Configuration(Integer.parseInt(sYear.getText()), Integer.parseInt(eYear.getText()), targetSite.getText(), true, cacheSources ,true);
				//Utils.ResetHistory();
				getRecommendedYears();
				break;
			}
			case "About":
			{
				JOptionPane.showMessageDialog(null, ABOUT);
				break;
			}
			
		}
	}
	
	private void getRecommendedYears()
	{
		
			if (SupportedCachingSites.getSelectedValue()==null)
			{
				JOptionPane.showMessageDialog(null, "Please select an archive source");
				return;	
			
			}
			String item = SupportedCachingSites.getSelectedValue();
		    switch (item) 
		    {
		    	case "WayBackMachine":
		    		wayback wb = new wayback();
		    		if (Utils.get_Site()==null || Utils.get_Site()=="")
		    		{
		    			JOptionPane.showMessageDialog(null, "Please enter a domain and save it..");
		    			break;
		    		}	
		    		
		    		try {
			    		String recsYear = wb.getYearByUrl(wb.GetRedirectedLink(Utils.get_Site(), "1900"));
			    		String receYear = wb.getYearByUrl(wb.GetRedirectedLink(Utils.get_Site(), "2020"));
			    		
			    		sYear.setText(recsYear);
			    		eYear.setText(receYear);
			    		
		    		} catch (Exception e)
		    		{
		    			JOptionPane.showMessageDialog(null, "Please choose another domain..");
		    		}

		    		
		    }
			
	}
	
	private void initComponents(Container contentPane,final JFrame frame)
    {

		infoPanel.setBorder(BorderFactory.createTitledBorder("Configuration"));
		infoPanel.setLayout(new GridBagLayout());  // one column
				
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.insets = new Insets(0,0,0,20);
		
		
		Utils u = new Utils();
		if (Utils.get_sYear()==0 && Utils.get_eYear()==0 )
		{
			Utils.set_sYear(2005);
			Utils.set_eYear(2006);
		}
		sYear = new JTextField(String.valueOf(Utils.get_sYear()));
		eYear = new JTextField(String.valueOf(Utils.get_eYear()));
		if (Utils.get_Site()!=null && Utils.get_Site()!="")
			targetSite = new JTextField (Utils.get_Site());
		else
			targetSite = new JTextField ("Host");
		SupportedCachingSites = new JList<String>(new String[]{"WayBackMachine"});
		
		if (SupportedCachingSites.getModel().getSize() > 0)
			SupportedCachingSites.setSelectedIndex(0);
		
		SupportedCachingSites.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent e) {
				CacheSource = SupportedCachingSites.getSelectedValue();
			}
		});
		

		gbc.gridy = 0;
		gbc.gridx = 0;
		
		infoPanel.add(sYear,gbc);
		gbc.gridy = 1;
		infoPanel.add(eYear,gbc);
		gbc.gridy = 2;
		infoPanel.add(targetSite,gbc);
		gbc.gridy = 3;
		infoPanel.add(SupportedCachingSites,gbc);
		gbc.gridy = 4;
		
		
		btnGetYears.setToolTipText("The GetYears button allows you to check snapshot years' ranges for a target domain");
		btnGetYears.setActionCommand("GetYears");
		btnGetYears.addActionListener(this);

		gbc.gridy = 5;
		infoPanel.add(btnGetYears,gbc);
		
		gbc.gridy = 6;
		About.setActionCommand("About");
		About.addActionListener(this);
		infoPanel.add(About,gbc);
		
		gbc.gridy = 7;
		infoPanel.add(HelpLabel1,gbc);
		
		gbc.gridy = 8;
		infoPanel.add(HelpLabel2,gbc);
		
		gbc.gridy = 9;
		infoPanel.add(HelpLabel3,gbc);
		
		gbc.gridy = 10;
		infoPanel.add(HelpLabel4,gbc);
		
		//begin component layout
		contentPane.add(infoPanel);
     
	}


}
