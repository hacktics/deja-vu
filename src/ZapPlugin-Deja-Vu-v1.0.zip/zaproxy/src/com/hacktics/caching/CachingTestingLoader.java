package com.hacktics.caching;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.util.HashMap;

import org.parosproxy.paros.network.HttpMessage;

import com.hacktics.caching.gui.CachingTesting;

public class CachingTestingLoader {

	
	public CachingTestingLoader() {	
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {

					CachingTesting frame = new CachingTesting();
			}
		});
	}

}
