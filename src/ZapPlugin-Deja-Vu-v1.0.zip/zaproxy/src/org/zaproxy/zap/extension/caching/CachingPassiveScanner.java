package org.zaproxy.zap.extension.caching;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import javax.help.plaf.basic.BasicFavoritesNavigatorUI.RemoveAction;
import javax.swing.JOptionPane;

import net.htmlparser.jericho.Source;

import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.URIException;
import org.apache.log4j.Logger;
import org.parosproxy.paros.control.Control;
import org.parosproxy.paros.core.scanner.Alert;
import org.parosproxy.paros.extension.history.ExtensionHistory;
import org.parosproxy.paros.model.HistoryList;
import org.parosproxy.paros.model.HistoryReference;
import org.parosproxy.paros.network.HttpHeader;
import org.parosproxy.paros.network.HttpMalformedHeaderException;
import org.parosproxy.paros.network.HttpMessage;
import org.parosproxy.paros.network.HttpRequestHeader;
import org.parosproxy.paros.network.HttpResponseHeader;
import org.zaproxy.zap.extension.pscan.PassiveScanThread;
import org.zaproxy.zap.extension.pscan.PluginPassiveScanner;
import org.zaproxy.zap.network.HttpRequestBody;
import org.zaproxy.zap.network.HttpResponseBody;

import com.hacktics.caching.main.CacheObject;
import com.hacktics.caching.main.URLObject;
//import com.hacktics.caching.main.SiteObject.CachingSites;
import com.hacktics.caching.parsers.GenericParser;
import com.hacktics.caching.parsers.Utils;
import com.hacktics.caching.parsers.wayback;


public class CachingPassiveScanner extends PluginPassiveScanner {

	private PassiveScanThread parent = null;
	private Logger logger = Logger.getLogger(this.getClass());
    private ResourceBundle messages = null;
    public static final String NAME = "Deja-Vu";
    private wayback wb = new wayback();
    //private ArrayList<String> HistoryLinks = new ArrayList<String>();


	@Override
	public void setParent (PassiveScanThread parent) {
		this.parent = parent;
	}

	@Override
	public void scanHttpRequestSend(HttpMessage msg, int id) {
		// Ignore

	}

	@Override
	public void scanHttpResponseReceive(HttpMessage msg, int id, Source source) {
		
		URI uri = null;
		String srcHost = null;
		String _URL = null;
		String _URLHost = null;
		String _Response = null; 
		String CurrentPath = null;
		String CurrentURL = null;
		
		_URL = msg.getRequestHeader().getURI().toString();
		try {
			_URLHost =  msg.getRequestHeader().getURI().getHost().toString();
		} catch (URIException e1) {
			e1.printStackTrace();
		}

		//Check Initialized Values
		srcHost = Utils.get_Site();//uri.getHost();
			
		if ((srcHost==null || Utils.get_sYear() == 0 || Utils.get_eYear() == 0 || !Utils.ExtensionExcluded(_URL)) )
		{
			if (!Utils.get_Notification())
			{
				JOptionPane.showMessageDialog(null, "Please configure the caching extension from Tools > Caching - Config");
				Utils.set_Notification(true);	
			}
			Utils.set_isActive(false);
			return;
		}
		else
		{
			Utils.set_Notification(true);
			Utils.set_isActive(true);
		}
		//if Active, Continue
		if (Utils.get_isActive() )
		{

			_Response = msg.getResponseBody().toString();

			if (_URLHost!=null && _URLHost.contains(srcHost) && !Utils.get_HistoryOriginalLinks().contains(_URLHost) ) {
				URLObject urlObject = new URLObject(_URL, _Response);
				
				ArrayList<String> OriginalLinks = urlObject.getSiteLinks();
				
				for (int i = Utils.get_sYear(); i <= Utils.get_eYear(); i++) {
					if (Utils.get_Site().contains(srcHost)) {
						HashMap<Utils.CachingSites, ArrayList<String>> CachedLinks = urlObject
								.get_CacheObject()
								.getModifiedCacheLinksFromSiteByYear(String.valueOf(i));

						try {
							CurrentPath = msg.getHistoryRef().getHttpMessage()
									.getRequestHeader().getURI().getPath()
									.toString();
							CurrentURL = urlObject.get_CacheObject().getArchiveSource().getArchiveObject(Utils.CachingSites.WayBackMachine).getArchiveParams().getUrl();
						} catch (HttpMalformedHeaderException | URIException
								| SQLException e) {
						}

						if (OriginalLinks != null && CachedLinks != null
								&& OriginalLinks.size() > 0
								&& CachedLinks.size() > 0) 
						{

							for (Map.Entry<Utils.CachingSites, ArrayList<String>> entry : CachedLinks
									.entrySet()) {

								Utils.CachingSites sourceSite = entry.getKey();
								ArrayList<String> sites = entry.getValue();

								for (String _site : sites) {

									if (_site != null) {
										URL _urlSite = null;
										try {
											_urlSite = new URL(_site);
										} catch (MalformedURLException e) {
											
										}
										if (!OriginalLinks.contains(_site))
											RaiseAlertCachedPage(
													sourceSite.toString(), msg,
													id,
													sourceSite.toString() + "("
															+ String.valueOf(i)
															+ ")", _site,
													Alert.RISK_MEDIUM, i,
													CurrentURL);
									}
								}
							}
						}
					}
				}
				
				urlObject.get_CacheObject().setUrlObject(urlObject);
			}
		}
	}


	private void RaiseAlertCachedPage(String CacheSource, HttpMessage msg, int id, String text, String url, int risk, int year, String param) 
	{
		
		String link = null;
			
		if (CacheSource==Utils.CachingSites.WayBackMachine.toString())	
		{
			link = wb.GetRedirectedLink(url, String.valueOf(year));
			if (link== null || link == "")
				link = param;
		}
		else
		{
			link = param;
		}
	
		String getYear = wb.getYearByUrl(link);
		if (getYear!=null || getYear !="")
			year = Integer.parseInt(getYear);
		
		text = 	"Hidden Links - " + CacheSource + "(" + year + ")";
		
		Alert alert = new Alert(getId(), risk, Alert.SUSPICIOUS, text);
		

			alert.setDetail(url,
				url,
				url  , link, String.valueOf(year),
	    		"Caching Solution", 
	            "Caching Reference", 
	            msg);
			
			
			
			parent.raiseAlert(id, alert);
    	
    	
	}

	private int getId() {
		return 10992;
	}

	@Override
	public String getName() {
		return NAME;
	}
	
	//public String getMessageString (String key) {
	//	return messages.getString(key);
	//}

}
