package org.zaproxy.zap.extension.caching;

import java.awt.Component;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

import com.hacktics.caching.main.*;
import com.hacktics.caching.parsers.Utils;
import com.hacktics.caching.parsers.wayback;

import org.apache.log4j.Logger;
import org.parosproxy.paros.control.Control;
import org.parosproxy.paros.core.scanner.Alert;
import org.parosproxy.paros.extension.history.ExtensionHistory;
import org.parosproxy.paros.model.Model;
import org.parosproxy.paros.network.HttpHeader;
import org.parosproxy.paros.network.HttpMalformedHeaderException;
import org.parosproxy.paros.network.HttpMessage;
import org.parosproxy.paros.network.HttpRequestHeader;
import org.parosproxy.paros.view.View;
import org.zaproxy.zap.extension.alert.AlertPanel;
import org.zaproxy.zap.extension.alert.ExtensionAlert;
import org.zaproxy.zap.extension.alert.PopupMenuAlertEdit;
import org.zaproxy.zap.view.PopupMenuHttpMessage;

import com.hacktics.caching.Caching;
import com.hacktics.caching.ZAP;

@SuppressWarnings("unused")
public class RightClickCaching extends PopupMenuHttpMessage {

	private static final long serialVersionUID = -8497133967174196949L;
	private CachingExtension extension = null;
	//private CachingCopyAlertsExtension extension = null;
	private final Logger logger = Logger.getLogger(this.getClass());
	private Alert alertNode;


	public RightClickCaching(String label) {
		super(label);
	}

	public void setExtension(CachingExtension extension) {
		this.extension = extension;
	}
	
    //@Override
    public boolean isEnableForComponent(Component invoker) {
    	
    	if (invoker.getName() != null && invoker.getName().equals("treeAlert")) {
            try {
                JTree tree = (JTree) invoker;
                if (tree.getLastSelectedPathComponent() != null) {
                    DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
			        
                    Object obj = node.getUserObject();
			        if (obj instanceof Alert)
			           this.alertNode = (Alert) obj;
                }
            } catch (Exception e) {}
            
        }
        //return false;
        
        return super.isEnableForComponent(invoker);
    }
	
	@Override
	public void performAction(HttpMessage msg) throws Exception {
		HttpMessage newmsg = null;
		HttpRequestHeader reqHeader = null;
		
		try {

			if (this.alertNode!=null)
			{
				wayback w = new wayback();
				reqHeader = new HttpRequestHeader(HttpRequestHeader.GET + " " + this.alertNode.getAttack() + " " + HttpHeader.HTTP11 + HttpHeader.CRLF + HttpHeader.CRLF);
		        reqHeader.setHeader(HttpRequestHeader.HOST, "web.archive.org");
			    //reqHeader.setHeader(HttpHeader.USER_AGENT, "DirBuster-0.12 (http://www.owasp.org/index.php/Category:OWASP_DirBuster_Project)");
			    reqHeader.setHeader(HttpHeader.PROXY_CONNECTION,"Keep-Alive");
			    reqHeader.setContentLength(0);
			}
		} catch (HttpMalformedHeaderException e) {
				e.printStackTrace();
		}
		
		newmsg = new HttpMessage(reqHeader);
		ZAP.showZapRepeater(newmsg);
	}

	@Override
	public boolean isEnableForInvoker(Invoker invoker) {
		return true;
	}


}
