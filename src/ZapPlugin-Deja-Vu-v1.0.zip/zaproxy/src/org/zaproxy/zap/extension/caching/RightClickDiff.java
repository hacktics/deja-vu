package org.zaproxy.zap.extension.caching;

import java.awt.Component;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

import com.hacktics.caching.main.*;
import com.hacktics.caching.parsers.Utils;
import com.hacktics.caching.parsers.wayback;

import org.apache.log4j.Logger;
import org.parosproxy.paros.Constant;
import org.parosproxy.paros.control.Control;
import org.parosproxy.paros.core.scanner.Alert;
import org.parosproxy.paros.extension.history.ExtensionHistory;
import org.parosproxy.paros.model.HistoryReference;
import org.parosproxy.paros.model.Model;
import org.parosproxy.paros.network.HttpHeader;
import org.parosproxy.paros.network.HttpMalformedHeaderException;
import org.parosproxy.paros.network.HttpMessage;
import org.parosproxy.paros.network.HttpRequestHeader;
import org.parosproxy.paros.view.View;
import org.zaproxy.zap.extension.alert.AlertPanel;
import org.zaproxy.zap.extension.alert.ExtensionAlert;
import org.zaproxy.zap.extension.alert.PopupMenuAlertEdit;
import org.zaproxy.zap.extension.bruteforce.BruteForce;
import org.zaproxy.zap.extension.bruteforce.BruteForceListenner;
import org.zaproxy.zap.extension.bruteforce.BruteForceParam;
import org.zaproxy.zap.view.PopupMenuHttpMessage;

import com.hacktics.caching.Caching;
import com.hacktics.caching.CachingTestingLoader;
import com.hacktics.caching.ZAP;
import com.sittinglittleduck.DirBuster.BaseCase;

@SuppressWarnings("unused")
public class RightClickDiff extends PopupMenuHttpMessage {

	private static final long serialVersionUID = -8497133967174196948L;
	private CachingExtension extension = null;
	//private CachingCopyAlertsExtension extension = null;
	private final Logger logger = Logger.getLogger(this.getClass());
	private Alert alertNode;
	private StringBuilder CopiedLinks;
    BruteForceListenner listener;

	/**
     * @param label
     */
	public RightClickDiff(String label) {
		super(label);
	}
	

	public void setExtension(CachingExtension extension) {
		this.extension = extension;
	}
	
    //@Override
    public boolean isEnableForComponent(Component invoker) {
 /*   	
    	if (invoker.getName() != null && invoker.getName().equals("treeAlert")) {
            try {
                JTree tree = (JTree) invoker;
                if (tree.getLastSelectedPathComponent() != null) {
                    DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
			        
                    Object obj = node.getUserObject();
			        if (obj instanceof Alert)
			        {
			           this.alertNode = (Alert) obj;
			        }
                }
            } catch (Exception e) {}
            
        }
        //return false;
        */
    	//return true;
        return super.isEnableForComponent(invoker);
    }

	@Override
	public void performAction(HttpMessage msg) throws Exception {
			CachingTestingLoader ct = new CachingTestingLoader();
	}

	@Override
	public boolean isEnableForInvoker(Invoker invoker) {
		return true;
	}

}
