package org.zaproxy.zap.extension.caching;

import java.awt.Component;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;

import com.hacktics.caching.main.*;
import com.hacktics.caching.parsers.Utils;
import com.hacktics.caching.parsers.wayback;

import org.apache.log4j.Logger;
import org.parosproxy.paros.Constant;
import org.parosproxy.paros.control.Control;
import org.parosproxy.paros.core.scanner.Alert;
import org.parosproxy.paros.extension.history.ExtensionHistory;
import org.parosproxy.paros.model.HistoryReference;
import org.parosproxy.paros.model.Model;
import org.parosproxy.paros.network.HttpHeader;
import org.parosproxy.paros.network.HttpMalformedHeaderException;
import org.parosproxy.paros.network.HttpMessage;
import org.parosproxy.paros.network.HttpRequestHeader;
import org.parosproxy.paros.view.View;
import org.zaproxy.zap.extension.alert.AlertNode;
import org.zaproxy.zap.extension.alert.AlertPanel;
import org.zaproxy.zap.extension.alert.ExtensionAlert;
import org.zaproxy.zap.extension.alert.PopupMenuAlertEdit;
import org.zaproxy.zap.extension.bruteforce.BruteForce;
import org.zaproxy.zap.extension.bruteforce.BruteForceListenner;
import org.zaproxy.zap.extension.bruteforce.BruteForceParam;
import org.zaproxy.zap.view.PopupMenuHttpMessage;

import com.hacktics.caching.Caching;
import com.hacktics.caching.CachingTestingLoader;
import com.hacktics.caching.ZAP;
import com.sittinglittleduck.DirBuster.BaseCase;

@SuppressWarnings("unused")
public class RightClickCopyCaching extends PopupMenuHttpMessage implements ClipboardOwner {

	private static final long serialVersionUID = -8497133967174196948L;
	private CachingExtension extension = null;
	//private CachingCopyAlertsExtension extension = null;
	private final Logger logger = Logger.getLogger(this.getClass());
	private Alert alertNode;
	private JTree treeNode;
	private StringBuilder CopiedLinks;
    BruteForceListenner listener;

	/**
     * @param label
     */
	public RightClickCopyCaching(String label) {
		super(label);
	}
	

	public void setExtension(CachingExtension extension) {
		this.extension = extension;
	}
	
    //@Override
    public boolean isEnableForComponent(Component invoker) {
    	
    	if (invoker.getName() != null && invoker.getName().equals("treeAlert")) {
            try {
                JTree tree = (JTree) invoker;
                if (tree.getLastSelectedPathComponent() != null) {
                	
                    DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
			        
                    
                    Object obj = node.getUserObject();
			        if (obj instanceof Alert)
			        {
			           //this.alertNode = (Alert) obj;
			           this.treeNode = tree;
			           getTreeHistory(treeNode,"");
			           //getAllHistory(this.alertNode.getHistoryRef(),this.alertNode.getAlert());
			        }
                }
            } catch (Exception e) {}
            
        }
        //return false;
        
        return super.isEnableForComponent(invoker);
    }
	
    //in the future when more archive sources will be supported we should make this code more dynamic
    private void getTreeHistory(JTree tree, String cls)
    {
    	ArrayList<String> links = new ArrayList<String>();
    	
    	cls = "WayBackMachine";
    	
    	StringBuilder sb = new StringBuilder();;
    	AlertNode root = (AlertNode) tree.getModel().getRoot();
        int num =  tree.getModel().getChildCount(root);
        
        for (int i=0;i<=num-1;i++)
        {
        	AlertNode rootnode = (AlertNode)tree.getModel().getChild(root, i);
        	int num2 =  tree.getModel().getChildCount(rootnode);
        	
    		
        	ArrayList<String> list = new ArrayList<String>();
    		for (int x=0;x<=num2-1;x++)
    		{
    			AlertNode alertnodeobject = (AlertNode)tree.getModel().getChild(rootnode, x);
    			Object alert2  = alertnodeobject.getUserObject();
		        if (alert2 instanceof Alert)
		        {	
		        	Alert alert = (Alert)alert2;
	    			if (alert.getAlert().toString().contains(cls))
	    			{
	    				if (!links.contains(alert.getParam()))
	    				{
	    					links.add(alert.getParam());
	    					sb.append(alert.getParam());
	    					sb.append("\n");
	    				}
	    				//list.add(alert.getAttack());
	    			}
		        }
    			
    		}
    		
        }
        
        CopiedLinks = sb;
    }
    
    
    private void getAllHistory(HistoryReference ref, String cls)
    {
    	
    	cls = "WayBackMachine";
		StringBuilder sb = new StringBuilder();
    	ArrayList<String> list = new ArrayList<String>();
		for (Alert alert : ref.getAlerts())
		{
			if (alert.getAlert().toString().contains(cls))
			{
	    		sb.append(alert.getParam());
	    		sb.append("\n");
				//list.add(alert.getAttack());
			}
		}
		CopiedLinks = sb;
    }
    
    
    
	@Override
	public void performAction(HttpMessage msg) throws Exception {

		if (this.CopiedLinks!=null)
		{
		    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		    clipboard.setContents( new StringSelection(CopiedLinks.toString()), this );

		}

	}

	@Override
	public boolean isEnableForInvoker(Invoker invoker) {
		return true;
	}

	@Override
	public void lostOwnership(Clipboard clipboard, Transferable contents) {
		// TODO Auto-generated method stub
	}




}
