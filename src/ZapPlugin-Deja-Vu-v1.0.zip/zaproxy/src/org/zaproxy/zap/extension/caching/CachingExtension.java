package org.zaproxy.zap.extension.caching;

import com.hacktics.caching.Caching;
import com.hacktics.caching.CachingTestingLoader;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JMenuItem;

import org.apache.log4j.Logger;
import org.parosproxy.paros.Constant;
import org.parosproxy.paros.extension.ExtensionAdaptor;
import org.parosproxy.paros.extension.ExtensionHook;

/*
 * This class defines the extension.
 */
public class CachingExtension extends ExtensionAdaptor {

    private JMenuItem mnuControlEvents = null;
    private JMenuItem mnuControlEvents2 = null;
    private RightClickCaching popupMsgControlEvents = null;
    private RightClickCopyCaching popupMsgControlEvents2 = null;
    private RightClickDiff popupMsgControlEvents3 = null;
    private ResourceBundle messages = null;
    
	private final Logger logger = Logger.getLogger(this.getClass());
	
	public static final String NAME = "CachePages"; 
  
	    public CachingExtension() {
	        super();
	        initialize();
	
	    }
	
        private void initialize() {
            this.setName(NAME); 	
        	messages = ResourceBundle.getBundle(
            		this.getClass().getPackage().getName() + ".Messages", Constant.getLocale());	

        }
        
        @Override
        public void hook(ExtensionHook extensionHook) {
            super.hook(extensionHook);
            
            if (getView() != null) {
                	// Register our top menu item, as long as we're not running as a daemon
                	extensionHook.getHookMenu().addToolsMenuItem(getmnuCaching());
                	extensionHook.getHookMenu().addToolsMenuItem(getmnuCaching2());
        	    	// Register our popup menu item, as long as we're not running as a daemon
        	    	extensionHook.getHookMenu().addPopupMenuItem(getPopupControlEvents());
        	    	extensionHook.getHookMenu().addPopupMenuItem(getPopupControlEvents2());
        	    	//extensionHook.getHookMenu().addPopupMenuItem(getPopupControlEvents3());
        	    }
        }

        
        private JMenuItem getmnuCaching2() {
/*        if (mnuControlEvents2 == null) {
        	mnuControlEvents2 = new JMenuItem();
        	mnuControlEvents2.setText(messages.getString("caching.menu.diff"));

        	mnuControlEvents2.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent e) {
                        // This is where you do what you want to do.
                        // In this case we'll just show a popup message.
                	try {
	                		new CachingTestingLoader();
	                		logger.info("Caching Diff Loaded");
	                	}
	                	catch (Exception ex) {
	                		logger.error(ex.getMessage(), ex);
	                	}
                	}
                });
        	}
        	return mnuControlEvents2;*/
        	return null;
        }
        
        

        private JMenuItem getmnuCaching() {
        if (mnuControlEvents == null) {
                mnuControlEvents = new JMenuItem();
                mnuControlEvents.setText(messages.getString("caching.menu"));

                mnuControlEvents.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent e) {
                        // This is where you do what you want to do.
                        // In this case we'll just show a popup message.
                	try {
	                		new Caching(null);
	                		logger.info("Caching Loaded");
	                	}
	                	catch (Exception ex) {
	                		logger.error(ex.getMessage(), ex);
	                	}
                	}
                });
        	}
        	return mnuControlEvents;
        }
        
        private RightClickCaching getPopupControlEvents() {
    		if (popupMsgControlEvents  == null) {
    			popupMsgControlEvents = new RightClickCaching(messages.getString("caching.menu.rightclick"));
    			popupMsgControlEvents.setExtension(this);
    			//popupMsgControlEvents.setExtension(this);
    		}
    		return popupMsgControlEvents;
    	}
        
        private RightClickCopyCaching getPopupControlEvents2() {
    		if (popupMsgControlEvents2  == null) {
    			popupMsgControlEvents2 = new RightClickCopyCaching(messages.getString("caching.menu.copylinks"));
    			popupMsgControlEvents2.setExtension(this);
    		}
    		return popupMsgControlEvents2;
    	}
        
        private RightClickDiff getPopupControlEvents3() {
    		if (popupMsgControlEvents3  == null) {
    			popupMsgControlEvents3 = new RightClickDiff(messages.getString("caching.menu.diff"));
    			popupMsgControlEvents3.setExtension(this);
    		}
    		return popupMsgControlEvents3;
    	}

        @Override
        public String getAuthor() {
                return messages.getString("caching.author");
        }

        @Override
        public String getDescription() {
                return messages.getString("caching.description");
        }

        @Override
        public URL getURL() {
                try {
                        return new URL("");
                } catch (MalformedURLException e) {
                        return null;
                }
        }
}